package 과제.팀과제3;

import 과제.팀과제3.view.MainView;

public class Application {
    public static void main(String[] args) {
        MainView.getInstance().run();
    }
}
