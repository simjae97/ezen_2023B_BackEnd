package 팀과제.팀과제1.조별과제3;

public class Application {
    public static void main(String[] args) {
        mainView.getInstance().run();
    }
}
