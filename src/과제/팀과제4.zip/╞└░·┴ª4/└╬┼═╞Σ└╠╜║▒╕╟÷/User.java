package 팀과제.팀과제4.인터페이스구현;

public interface User {

    // public abstract void attack();
    void attack(); // public abstract 은 interface 라서 생략 가능.
}
