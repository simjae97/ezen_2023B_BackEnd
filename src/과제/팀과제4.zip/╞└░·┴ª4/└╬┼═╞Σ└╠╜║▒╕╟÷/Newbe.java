package 팀과제.팀과제4.인터페이스구현;

public class Newbe implements User {

    public void attack(){
        System.out.println("초보자 : 기본공격");
    }
}
