package 팀과제.팀과제4.인터페이스구현;

public class Archor implements User {

    @Override
    public void attack() {
        System.out.println("궁수 : 더블 에로우 발사");
    }
}
