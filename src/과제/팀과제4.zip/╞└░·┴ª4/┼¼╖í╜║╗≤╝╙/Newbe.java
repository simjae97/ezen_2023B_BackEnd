package 팀과제.팀과제4.클래스상속;

public class Newbe {

    public void attack(){
        System.out.println("초보자 : 기본공격");
    }
}
