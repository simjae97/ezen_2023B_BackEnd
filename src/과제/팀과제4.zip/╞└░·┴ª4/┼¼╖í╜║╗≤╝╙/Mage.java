package 팀과제.팀과제4.클래스상속;

public class Mage extends Newbe {

    @Override
    public void attack() {
        System.out.println("마법사 : 에너지 볼트 발사");
    }
}
