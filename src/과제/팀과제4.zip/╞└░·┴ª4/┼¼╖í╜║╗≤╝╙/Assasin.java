package 팀과제.팀과제4.클래스상속;

public class Assasin extends Newbe {

    @Override
    public void attack() {
        System.out.println("도적 : 럭키세븐 발사");
    }
}
